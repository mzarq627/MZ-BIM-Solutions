# -*- coding: utf-8 -*-

from licencia import validate_license


# =========================================================
# EJECUCIÓN AUTOMÁTICA AL ABRIR REVIT
# =========================================================
try:
    validate_license()
except:
    # evita que Revit falle si hay error de red
    pass