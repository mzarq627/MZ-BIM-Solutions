# -*- coding: utf-8 -*-

import os
import json
import urllib2
from datetime import datetime
from pyrevit import forms


# =========================================================
# URL DE LICENCIAS EN GITHUB
# =========================================================
LICENSE_URL = "https://raw.githubusercontent.com/mzarq627/MZ-BIM-Solutions/main/licenses.json"


# =========================================================
# OBTENER LICENCIA LOCAL (instalada por launcher)
# =========================================================
def get_local_license():
    try:
        appdata = os.getenv("APPDATA")
        path = os.path.join(appdata, "MZBIM", "license.json")

        if not os.path.exists(path):
            return None

        with open(path, "r") as f:
            data = json.load(f)

        return data.get("licenseCode")

    except:
        return None


# =========================================================
# DESCARGAR LICENCIAS DESDE GITHUB
# =========================================================
def load_remote_licenses():
    try:
        response = urllib2.urlopen(LICENSE_URL)
        return json.loads(response.read())
    except:
        return None


# =========================================================
# VALIDACIÓN BASE DE LICENCIA
# =========================================================
def validate_license():

    license_code = get_local_license()

    if not license_code:
        forms.alert("No hay licencia instalada", exitscript=True)

    data = load_remote_licenses()

    if not data:
        forms.alert("No se pudo conectar al servidor de licencias", exitscript=True)

    if license_code not in data:
        forms.alert("Licencia inválida", exitscript=True)

    lic = data[license_code]

    if not lic.get("active", False):
        forms.alert("Licencia desactivada", exitscript=True)

    return lic


# =========================================================
# VALIDAR PLUGIN ESPECÍFICO
# =========================================================
def validar_plugin(plugin_id):

    lic = validate_license()

    plugins = lic.get("plugins", {})

    if plugin_id not in plugins:
        forms.alert("No tienes acceso a este plugin", exitscript=True)

    plugin = plugins[plugin_id]

    if not plugin.get("active", False):
        forms.alert("Plugin desactivado", exitscript=True)

    expira = plugin.get("expira", "")

    try:
        exp_date = datetime.strptime(expira, "%Y-%m-%d")
    except:
        forms.alert("Fecha de expiración inválida", exitscript=True)

    if datetime.now() > exp_date:
        forms.alert("Licencia vencida", exitscript=True)

    return True