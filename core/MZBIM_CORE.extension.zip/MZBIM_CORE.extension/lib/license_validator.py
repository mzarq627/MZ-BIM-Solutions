# -*- coding: utf-8 -*-

import os
import json
import sys

try:
    from System.Windows import MessageBox
except:
    MessageBox = None


LICENSE_FOLDER = os.path.join(
    os.environ["APPDATA"],
    "MZBIM"
)

LICENSE_FILE = os.path.join(
    LICENSE_FOLDER,
    "license.json"
)


def show_error(message):
    try:
        if MessageBox:
            MessageBox.Show(message)
        else:
            print(message)
    except:
        print(message)


def validate_plugin():

    if not os.path.exists(LICENSE_FILE):

        show_error(
            "LICENCIA NO ENCONTRADA.\n\nACTIVA TU LICENCIA DESDE EL LAUNCHER."
        )

        sys.exit()

    try:

        with open(LICENSE_FILE, "r") as f:
            data = json.load(f)

        license_code = data.get(
            "licenseCode",
            ""
        )

        if not license_code:

            show_error(
                "LICENCIA INVALIDA."
            )

            sys.exit()

        return True

    except Exception as ex:

        show_error(
            "ERROR VALIDANDO LICENCIA\n\n{}".format(ex)
        )

        sys.exit()


# =========================================================
# COMPATIBILIDAD CON VERSIONES ANTERIORES
# =========================================================

def check():
    return validate_plugin()


def check_license():
    return validate_plugin()