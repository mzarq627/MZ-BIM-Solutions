# -*- coding: utf-8 -*-

from pyrevit import script, forms

from Autodesk.Revit.DB import (
    FilteredElementCollector,
    BuiltInCategory,
    BuiltInParameter,
    SpatialElementBoundaryOptions,
    Transaction,
    Wall,
    WallType,
    Level,
    Element,
    XYZ,
    Transform,
    JoinGeometryUtils
)

from System.Windows.Media import Brushes
from System.Windows.Media.Imaging import BitmapImage
from System.Windows.Controls import CheckBox
from System.Windows import Thickness
from System import Uri

# =========================================================
# DOCUMENTO
# =========================================================

uidoc = __revit__.ActiveUIDocument
doc = uidoc.Document

FT = 3.28084


# =========================================================
# REVESTIMIENTO PRO - MZ BIM TECHNOLOGY
# =========================================================

class RevestimientoPRO(forms.WPFWindow):

    def __init__(self):

        xamlfile = script.get_bundle_file('ui.xaml')
        forms.WPFWindow.__init__(self, xamlfile)

        # =====================================================
        # LOGO
        # =====================================================

        try:
            logo_path = script.get_bundle_file('logo.png')
            self.logoImage.Source = BitmapImage(Uri(logo_path))
        except:
            pass

        # =====================================================
        # DATA
        # =====================================================

        self.level_dict = {}
        self.room_dict = {}
        self.wall_type_dict = {}

        self.load_levels()
        self.load_wall_types()

        self.ShowDialog()

    # =====================================================
    # NIVELES
    # =====================================================

    def load_levels(self):

        levels = FilteredElementCollector(doc) \
            .OfClass(Level) \
            .ToElements()

        ordered_levels = sorted(levels, key=lambda x: x.Elevation)

        for lvl in ordered_levels:

            try:
                self.level_dict[lvl.Name] = lvl
                self.levelCombo.Items.Add(lvl.Name)
            except:
                pass

    # =====================================================
    # TIPOS DE MURO
    # =====================================================

    def load_wall_types(self):

        wall_types = FilteredElementCollector(doc) \
            .OfClass(WallType) \
            .ToElements()

        names = []

        for wt in wall_types:

            try:
                name = Element.Name.GetValue(wt)

                if name not in self.wall_type_dict:
                    self.wall_type_dict[name] = wt
                    names.append(name)

            except:
                pass

        names.sort()

        for n in names:
            self.wallTypeCombo.Items.Add(n)

    # =====================================================
    # CAMBIO NIVEL → HABITACIONES
    # =====================================================

    def level_changed(self, sender, args):

        self.roomsPanel.Children.Clear()
        self.room_dict.clear()

        level_name = self.levelCombo.SelectedItem

        if not level_name:
            return

        selected_level = self.level_dict[level_name]
        selected_level_id = selected_level.Id

        rooms = FilteredElementCollector(doc) \
            .OfCategory(BuiltInCategory.OST_Rooms) \
            .WhereElementIsNotElementType() \
            .ToElements()

        room_names = []

        for room in rooms:

            try:

                if room.Area <= 0:
                    continue

                if room.LevelId != selected_level_id:
                    continue

                name_param = room.get_Parameter(BuiltInParameter.ROOM_NAME)
                number_param = room.get_Parameter(BuiltInParameter.ROOM_NUMBER)

                if not name_param or not number_param:
                    continue

                name = name_param.AsString()
                number = number_param.AsString()

                display = '{} - {}'.format(number, name)

                self.room_dict[display] = room
                room_names.append(display)

            except:
                pass

        room_names.sort()

        for display in room_names:

            cb = CheckBox()
            cb.Content = display
            cb.Foreground = Brushes.White
            cb.Margin = Thickness(5, 2, 5, 2)
            cb.FontSize = 13
            cb.Height = 28

            self.roomsPanel.Children.Add(cb)

    # =====================================================
    # SEGMENTOS ROOM
    # =====================================================

    def get_room_segments(self, room):

        options = SpatialElementBoundaryOptions()
        boundaries = room.GetBoundarySegments(options)

        segments = []

        if not boundaries:
            return segments

        MIN_LENGTH = 0.10 * FT

        for boundary in boundaries:

            for seg in boundary:

                try:

                    curve = seg.GetCurve()

                    if curve.Length < MIN_LENGTH:
                        continue

                    segments.append((curve, seg.ElementId))

                except:
                    pass

        return segments

    # =====================================================
    # OFFSET INTERIOR
    # =====================================================

    def offset_curve(self, curve, wall_type):

        try:
            width = wall_type.Width
        except:
            width = 0.10

        half_width = width / 2.0

        start = curve.GetEndPoint(0)
        end = curve.GetEndPoint(1)

        direction = (end - start).Normalize()

        normal = XYZ(-direction.Y, direction.X, 0)

        return curve.CreateTransformed(
            Transform.CreateTranslation(normal * half_width)
        )

    # =====================================================
    # CREAR REVESTIMIENTO
    # =====================================================

    def create_revestimiento(self, sender, args):

        level_name = self.levelCombo.SelectedItem
        wall_type_name = self.wallTypeCombo.SelectedItem

        if not level_name or not wall_type_name:
            self.statusText.Text = 'Seleccione nivel y tipo'
            return

        # =====================================================
        # ALTURA
        # =====================================================

        try:
            height_m = float(self.heightBox.Text.replace(',', '.'))
        except:
            self.statusText.Text = 'Altura inválida'
            return

        selected_level = self.level_dict[level_name]
        selected_wall_type = self.wall_type_dict[wall_type_name]

        height_ft = height_m * FT

        # =====================================================
        # HABITACIONES SELECCIONADAS
        # =====================================================

        selected_rooms = []

        for item in self.roomsPanel.Children:

            try:
                if item.IsChecked:
                    selected_rooms.append(
                        self.room_dict[item.Content]
                    )
            except:
                pass

        if not selected_rooms:
            self.statusText.Text = 'Seleccione habitaciones'
            return

        # =====================================================
        # TRANSACCION
        # =====================================================

        t = Transaction(doc, 'MZ BIM - Revestimiento PRO')
        t.Start()

        created = 0

        for room in selected_rooms:

            segments = self.get_room_segments(room)

            for curve, eid in segments:

                try:

                    offset = self.offset_curve(
                        curve,
                        selected_wall_type
                    )

                    wall = Wall.Create(
                        doc,
                        offset,
                        selected_wall_type.Id,
                        selected_level.Id,
                        height_ft,
                        0,
                        False,
                        False
                    )

                    doc.Regenerate()

                    # =====================================================
                    # UNIR GEOMETRIA
                    # =====================================================

                    try:

                        host = doc.GetElement(eid)

                        if host:

                            already_joined = JoinGeometryUtils.AreElementsJoined(
                                doc,
                                host,
                                wall
                            )

                            if not already_joined:

                                JoinGeometryUtils.JoinGeometry(
                                    doc,
                                    host,
                                    wall
                                )

                    except:
                        pass

                    created += 1

                except:
                    pass

        t.Commit()

        # =====================================================
        # MENSAJE FINAL
        # =====================================================

        forms.alert(
            'Se crearon {} muros correctamente.'.format(created),
            title='MZ BIM TECHNOLOGY'
        )

        self.Close()


# =========================================================
# EJECUTAR
# =========================================================

RevestimientoPRO()