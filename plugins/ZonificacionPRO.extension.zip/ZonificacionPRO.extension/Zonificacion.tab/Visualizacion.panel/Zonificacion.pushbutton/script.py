# =========================================================
# ZONIFICACION PRO
# VERSION FINAL ESTABLE
# COLOR PICKER + ALTURA AUTOMATICA
# =========================================================

# -*- coding: utf-8 -*-

from pyrevit import revit, DB, forms, script
from Autodesk.Revit.UI import TaskDialog

from System.Windows.Controls import *
from System.Windows.Media import SolidColorBrush, Color
from System.Windows import Thickness, CornerRadius
from System.Windows.Media.Imaging import BitmapImage
from System.Collections.Generic import List
from System import Uri

from System.Windows.Forms import ColorDialog, DialogResult

import random

# =========================================================
# REVIT
# =========================================================

doc = revit.doc
uidoc = revit.uidoc

# =========================================================
# XAML
# =========================================================

xamlfile = script.get_bundle_file("ui.xaml")

# =========================================================
# GET ROOMS
# =========================================================

rooms = list(
    DB.FilteredElementCollector(doc)
    .OfCategory(DB.BuiltInCategory.OST_Rooms)
    .WhereElementIsNotElementType()
)

# =========================================================
# GROUP ROOMS
# =========================================================

room_groups = {}

for room in rooms:

    try:

        room_name = room.get_Parameter(
            DB.BuiltInParameter.ROOM_NAME
        ).AsString()

        if not room_name:
            continue

        if room_name not in room_groups:
            room_groups[room_name] = []

        room_groups[room_name].append(room)

    except:
        pass

# =========================================================
# COLOR SYSTEM
# =========================================================

color_map = {}

def get_color(name):

    if name not in color_map:

        random.seed(name)

        color_map[name] = (
            random.randint(80,255),
            random.randint(80,255),
            random.randint(80,255)
        )

    return color_map[name]

# =========================================================
# CREATE VIEW NAME
# =========================================================

def create_view_name():

    views = DB.FilteredElementCollector(doc)\
        .OfClass(DB.View3D)

    names = []

    for v in views:

        try:
            names.append(v.Name)
        except:
            pass

    i = 1

    while True:

        name = "Zonificacion {}".format(i)

        if name not in names:
            return name

        i += 1

# =========================================================
# CREATE 3D VIEW
# =========================================================

def create_3d_view():

    view_family_type = None

    for vft in DB.FilteredElementCollector(doc)\
        .OfClass(DB.ViewFamilyType):

        try:

            if vft.ViewFamily == DB.ViewFamily.ThreeDimensional:

                view_family_type = vft
                break

        except:
            pass

    if not view_family_type:
        return None

    view = DB.View3D.CreateIsometric(
        doc,
        view_family_type.Id
    )

    view.Name = create_view_name()

    return view

# =========================================================
# ROOM HEIGHT
# =========================================================

def get_room_height(room):

    default_height = 2500 / 304.8

    try:

        current_level = doc.GetElement(room.LevelId)

        if not current_level:
            return default_height

        # =================================================
        # UPPER LEVEL
        # =================================================

        upper_level_id = room.get_Parameter(
            DB.BuiltInParameter.ROOM_UPPER_LEVEL
        ).AsElementId()

        upper_level = doc.GetElement(upper_level_id)

        if upper_level:

            height = upper_level.Elevation - current_level.Elevation

            if height > 0:
                return height

        # =================================================
        # NEXT LEVEL
        # =================================================

        levels = sorted(
            list(
                DB.FilteredElementCollector(doc)
                .OfClass(DB.Level)
            ),
            key=lambda x: x.Elevation
        )

        current_elev = current_level.Elevation

        for lvl in levels:

            if lvl.Elevation > current_elev:

                height = lvl.Elevation - current_elev

                if height > 0:
                    return height

    except:
        pass

    return default_height

# =========================================================
# WINDOW
# =========================================================

class ZonificacionWindow(forms.WPFWindow):

    def __init__(self):

        forms.WPFWindow.__init__(self, xamlfile)

        self.room_controls = []

        # =================================================
        # CUSTOM COLORS
        # =================================================

        self.custom_colors = {}

        # =================================================
        # LOGO
        # =================================================

        try:

            logo_path = script.get_bundle_file("logo.png")

            bitmap = BitmapImage()

            bitmap.BeginInit()
            bitmap.UriSource = Uri(logo_path)
            bitmap.EndInit()

            self.LogoImage.Source = bitmap

        except:
            pass

        # =================================================
        # LOAD ROOMS
        # =================================================

        self.load_rooms()

        # =================================================
        # EVENTS
        # =================================================

        self.SelectAllRoomsButton.Click += self.select_all
        self.DeselectAllRoomsButton.Click += self.deselect_all
        self.GenerateButton.Click += self.generate

        self.ShowDialog()

    # =====================================================
    # PICK COLOR
    # =====================================================

    def pick_color(self, sender, args):

        room_name = sender.Tag

        dialog = ColorDialog()

        result = dialog.ShowDialog()

        if result == DialogResult.OK:

            rgb = (
                dialog.Color.R,
                dialog.Color.G,
                dialog.Color.B
            )

            self.custom_colors[room_name] = rgb

            sender.Background = SolidColorBrush(
                Color.FromRgb(
                    rgb[0],
                    rgb[1],
                    rgb[2]
                )
            )

    # =====================================================
    # LOAD ROOMS
    # =====================================================

    def load_rooms(self):

        self.RoomsPanel.Children.Clear()

        self.room_controls = []

        for room_name in sorted(room_groups.keys()):

            rgb = self.custom_colors.get(
                room_name,
                get_color(room_name)
            )

            # =================================================
            # CARD
            # =================================================

            border = Border()

            border.Background = SolidColorBrush(
                Color.FromRgb(52,52,60)
            )

            border.Padding = Thickness(10)

            border.Margin = Thickness(0,0,0,8)

            border.CornerRadius = CornerRadius(8)

            # =================================================
            # MAIN STACK
            # =================================================

            main_stack = StackPanel()

            # =================================================
            # TOP ROW
            # =================================================

            top_stack = StackPanel()

            top_stack.Orientation = Orientation.Horizontal

            # =================================================
            # CHECKBOX
            # =================================================

            cb = CheckBox()

            cb.Content = "{} ({})".format(
                room_name,
                len(room_groups[room_name])
            )

            cb.IsChecked = False

            cb.Foreground = SolidColorBrush(
                Color.FromRgb(255,255,255)
            )

            cb.FontSize = 14

            cb.Width = 300

            # =================================================
            # COLOR BUTTON
            # =================================================

            color_btn = Button()

            color_btn.Width = 40
            color_btn.Height = 20

            color_btn.Margin = Thickness(10,0,0,0)

            color_btn.BorderThickness = Thickness(0)

            color_btn.Tag = room_name

            color_btn.Background = SolidColorBrush(
                Color.FromRgb(
                    rgb[0],
                    rgb[1],
                    rgb[2]
                )
            )

            color_btn.Click += self.pick_color

            # =================================================
            # ADD
            # =================================================

            top_stack.Children.Add(cb)
            top_stack.Children.Add(color_btn)

            main_stack.Children.Add(top_stack)

            border.Child = main_stack

            self.RoomsPanel.Children.Add(border)

            self.room_controls.append(
                (room_name, cb)
            )

    # =====================================================
    # SELECT ALL
    # =====================================================

    def select_all(self, sender, args):

        for room_name, cb in self.room_controls:
            cb.IsChecked = True

    # =====================================================
    # DESELECT ALL
    # =====================================================

    def deselect_all(self, sender, args):

        for room_name, cb in self.room_controls:
            cb.IsChecked = False

    # =====================================================
    # GENERATE
    # =====================================================

    def generate(self, sender, args):

        t = DB.Transaction(doc, "Zonificacion")

        try:

            t.Start()

            # =================================================
            # CREATE VIEW
            # =================================================

            view3d = create_3d_view()

            if not view3d:

                t.RollBack()

                TaskDialog.Show(
                    "Error",
                    "No se pudo crear vista 3D"
                )

                return

            # =================================================
            # SOLID FILL
            # =================================================

            solid_fill = None

            patterns = DB.FilteredElementCollector(doc)\
                .OfClass(DB.FillPatternElement)

            for p in patterns:

                try:

                    if p.GetFillPattern().IsSolidFill:

                        solid_fill = p
                        break

                except:
                    pass

            # =================================================
            # ROOM OPTIONS
            # =================================================

            opt = DB.SpatialElementBoundaryOptions()

            opt.SpatialElementBoundaryLocation = \
                DB.SpatialElementBoundaryLocation.Finish

            # =================================================
            # CREATE BLOCKS
            # =================================================

            created = 0

            for room_name, cb in self.room_controls:

                if not cb.IsChecked:
                    continue

                rgb = self.custom_colors.get(
                    room_name,
                    get_color(room_name)
                )

                for room in room_groups[room_name]:

                    try:

                        boundaries = room.GetBoundarySegments(opt)

                        if not boundaries:
                            continue

                        loop_list = List[DB.CurveLoop]()

                        valid_loop = None

                        for seglist in boundaries:

                            try:

                                loop = DB.CurveLoop()

                                for seg in seglist:

                                    curve = seg.GetCurve()

                                    if curve:
                                        loop.Append(curve)

                                valid_loop = loop
                                break

                            except:
                                continue

                        if not valid_loop:
                            continue

                        loop_list.Add(valid_loop)

                        # =========================================
                        # AUTO HEIGHT
                        # =========================================

                        height = get_room_height(room)

                        # =========================================
                        # CREATE SOLID
                        # =========================================

                        solid = DB.GeometryCreationUtilities.CreateExtrusionGeometry(
                            loop_list,
                            DB.XYZ.BasisZ,
                            height
                        )

                        # =========================================
                        # DIRECT SHAPE
                        # =========================================

                        ds = DB.DirectShape.CreateElement(
                            doc,
                            DB.ElementId(
                                DB.BuiltInCategory.OST_GenericModel
                            )
                        )

                        ds.SetShape([solid])

                        # =========================================
                        # COLORS
                        # =========================================

                        override = DB.OverrideGraphicSettings()

                        if solid_fill:

                            override.SetSurfaceForegroundPatternId(
                                solid_fill.Id
                            )

                            override.SetSurfaceForegroundPatternVisible(True)

                            override.SetSurfaceForegroundPatternColor(
                                DB.Color(
                                    rgb[0],
                                    rgb[1],
                                    rgb[2]
                                )
                            )

                        override.SetProjectionLineColor(
                            DB.Color(
                                rgb[0],
                                rgb[1],
                                rgb[2]
                            )
                        )

                        view3d.SetElementOverrides(
                            ds.Id,
                            override
                        )

                        created += 1

                    except:
                        continue

            # =================================================
            # HIDE EVERYTHING
            # =================================================

            for cat in doc.Settings.Categories:

                try:

                    if cat.Id.IntegerValue == int(
                        DB.BuiltInCategory.OST_GenericModel
                    ):
                        continue

                    view3d.SetCategoryHidden(cat.Id, True)

                except:
                    pass

            # =================================================
            # VISUAL STYLE
            # =================================================

            try:
                view3d.DisplayStyle = DB.DisplayStyle.Shading
            except:
                pass

            t.Commit()

            uidoc.ActiveView = view3d

            TaskDialog.Show(
                "Zonificacion",
                "Vista creada correctamente\n\n"
                "Vista: {}\n"
                "Bloques creados: {}".format(
                    view3d.Name,
                    created
                )
            )

            self.Close()

        except Exception as e:

            try:
                t.RollBack()
            except:
                pass

            TaskDialog.Show(
                "ERROR",
                str(e)
            )

# =========================================================
# START
# =========================================================

ZonificacionWindow()