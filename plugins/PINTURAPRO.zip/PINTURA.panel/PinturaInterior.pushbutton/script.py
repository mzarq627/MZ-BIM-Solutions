# -*- coding: utf-8 -*-

from pyrevit import forms
from pyrevit.forms import WPFWindow
from pyrevit import script

from Autodesk.Revit.DB import *

from System.Windows.Controls import CheckBox
from System.Windows.Media import Brushes
from System.Windows import Thickness
from System import Uri
from System.Windows.Media.Imaging import BitmapImage

# =========================================================
# DOCUMENTO
# =========================================================

uidoc = __revit__.ActiveUIDocument
doc = uidoc.Document

# =========================================================
# VENTANA PRINCIPAL
# =========================================================

class PaintRoomWindow(WPFWindow):

    def __init__(self):

        xamlfile = script.get_bundle_file('ui.xaml')

        WPFWindow.__init__(self, xamlfile)

        # =====================================================
        # LOGO
        # =====================================================

        try:

            logo_path = script.get_bundle_file('logo.png')

            bitmap = BitmapImage()

            bitmap.BeginInit()

            bitmap.UriSource = Uri(logo_path)

            bitmap.EndInit()

            self.logoImage.Source = bitmap

        except:
            pass

        # =====================================================
        # DICCIONARIOS
        # =====================================================

        self.level_dict = {}
        self.room_dict = {}
        self.material_dict = {}

        # =====================================================
        # CARGAR DATOS
        # =====================================================

        self.load_levels()
        self.load_materials()

        self.levelCombo.SelectionChanged += self.level_changed

        self.ShowDialog()

    # =========================================================
    # CARGAR NIVELES
    # =========================================================

    def load_levels(self):

        levels = FilteredElementCollector(doc)\
            .OfClass(Level)\
            .ToElements()

        ordered_levels = sorted(
            levels,
            key=lambda x: x.Elevation
        )

        for lvl in ordered_levels:

            try:

                self.level_dict[lvl.Name] = lvl

                self.levelCombo.Items.Add(
                    lvl.Name
                )

            except:
                pass

    # =========================================================
    # CAMBIO NIVEL
    # =========================================================

    def level_changed(self, sender, args):

        self.roomsPanel.Children.Clear()

        self.room_dict = {}

        selected_level_name = self.levelCombo.SelectedItem

        if not selected_level_name:
            return

        selected_level = self.level_dict[
            selected_level_name
        ]

        rooms = FilteredElementCollector(doc)\
            .OfCategory(BuiltInCategory.OST_Rooms)\
            .WhereElementIsNotElementType()\
            .ToElements()

        room_names = []

        for room in rooms:

            try:

                if room.Area <= 0:
                    continue

                room_level = doc.GetElement(
                    room.LevelId
                )

                if not room_level:
                    continue

                if room_level.Id != selected_level.Id:
                    continue

                room_name = room.get_Parameter(
                    BuiltInParameter.ROOM_NAME
                ).AsString()

                room_number = room.get_Parameter(
                    BuiltInParameter.ROOM_NUMBER
                ).AsString()

                display = "{} - {}".format(
                    room_number,
                    room_name
                )

                self.room_dict[display] = room

                room_names.append(display)

            except:
                pass

        room_names.sort()

        for display in room_names:

            cb = CheckBox()

            cb.Content = display
            cb.Foreground = Brushes.White
            cb.Margin = Thickness(0, 5, 0, 5)
            cb.FontSize = 13
            cb.Height = 28

            self.roomsPanel.Children.Add(cb)

    # =========================================================
    # CARGAR MATERIALES
    # =========================================================

    def load_materials(self):

        materials = FilteredElementCollector(doc)\
            .OfClass(Material)\
            .ToElements()

        material_names = []

        for mat in materials:

            try:

                if mat.Name not in self.material_dict:

                    self.material_dict[
                        mat.Name
                    ] = mat

                    material_names.append(
                        mat.Name
                    )

            except:
                pass

        material_names.sort()

        for name in material_names:

            self.materialCombo.Items.Add(name)

    # =========================================================
    # ELEMENTOS DEL ROOM
    # =========================================================

    def get_room_elements(self, room):

        options = SpatialElementBoundaryOptions()

        boundaries = room.GetBoundarySegments(
            options
        )

        ids = set()

        if not boundaries:
            return []

        for boundary in boundaries:

            for segment in boundary:

                try:

                    curve = segment.GetCurve()

                    if curve.Length < 0.10:
                        continue

                    ids.add(
                        segment.ElementId.IntegerValue
                    )

                except:
                    pass

        return [ElementId(i) for i in ids]

    # =========================================================
    # CENTRO ROOM
    # =========================================================

    def get_room_center(self, room):

        bbox = room.get_BoundingBox(None)

        if not bbox:
            return None

        return (bbox.Min + bbox.Max) / 2

    # =========================================================
    # VALIDAR CARA INTERIOR
    # =========================================================

    def is_face_facing_room(self, face, room_center):

        try:

            bbox = face.GetBoundingBox()

            uv = (bbox.Min + bbox.Max) / 2

            normal = face.ComputeNormal(uv)

            point = face.Evaluate(uv)

            direction = (
                room_center - point
            ).Normalize()

            dot = normal.DotProduct(direction)

            return dot > 0.2

        except:
            return False

    # =========================================================
    # PINTAR HABITACIONES
    # =========================================================

    def paint_rooms(self, sender, args):

        selected_material_name = self.materialCombo.SelectedItem

        if not selected_material_name:

            forms.alert(
                "Selecciona un material."
            )

            return

        selected_rooms = []

        for cb in self.roomsPanel.Children:

            try:

                if cb.IsChecked:

                    room = self.room_dict[
                        cb.Content
                    ]

                    selected_rooms.append(room)

            except:
                pass

        if not selected_rooms:

            forms.alert(
                "Selecciona habitaciones."
            )

            return

        selected_material = self.material_dict[
            selected_material_name
        ]

        t = Transaction(
            doc,
            "Pintura Interior PRO"
        )

        t.Start()

        painted = 0
        errors = []

        for room in selected_rooms:

            try:

                room_center = self.get_room_center(room)

                if not room_center:
                    continue

                element_ids = self.get_room_elements(room)

                for eid in element_ids:

                    try:

                        element = doc.GetElement(eid)

                        if not element:
                            continue

                        valid = False

                        if isinstance(element, Wall):
                            valid = True

                        else:

                            try:

                                if element.Category:

                                    if element.Category.Id.IntegerValue == int(
                                        BuiltInCategory.OST_StructuralColumns
                                    ):

                                        valid = True

                            except:
                                pass

                        if not valid:
                            continue

                        options = Options()

                        options.ComputeReferences = True
                        options.IncludeNonVisibleObjects = False

                        geom = element.get_Geometry(options)

                        if not geom:
                            continue

                        for geo in geom:

                            solid = geo

                            try:

                                faces = solid.Faces

                            except:
                                continue

                            for face in faces:

                                try:

                                    if not self.is_face_facing_room(
                                        face,
                                        room_center
                                    ):
                                        continue

                                    doc.Paint(
                                        element.Id,
                                        face,
                                        selected_material.Id
                                    )

                                    painted += 1

                                except:
                                    pass

                    except Exception as e:

                        try:
                            errors.append(str(e))
                        except:
                            errors.append(
                                "Error desconocido"
                            )

            except Exception as e:

                try:

                    room_name = room.get_Parameter(
                        BuiltInParameter.ROOM_NAME
                    ).AsString()

                except:

                    room_name = "Habitación"

                errors.append(
                    "{} --> {}".format(
                        room_name,
                        str(e)
                    )
                )

        t.Commit()

        msg = "CARAS PINTADAS: {}\n".format(
            painted
        )

        if errors:

            msg += "\nERRORES:\n\n"

            for err in errors:
                msg += err + "\n"

        forms.alert(
            msg,
            title="Proceso Finalizado"
        )

        self.Close()

# =========================================================
# EJECUTAR
# =========================================================

PaintRoomWindow()