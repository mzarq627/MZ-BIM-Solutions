# -*- coding: utf-8 -*-

from pyrevit import forms
from pyrevit.forms import WPFWindow
from pyrevit import script

from Autodesk.Revit.DB import (
    FilteredElementCollector,
    BuiltInCategory,
    BuiltInParameter,
    SpatialElementBoundaryOptions,
    Transaction,
    Ceiling,
    CeilingType,
    Level,
    Element,
    CurveLoop
)

from System.Collections.Generic import List

from System.Windows.Controls import CheckBox
from System.Windows.Media import Brushes
from System.Windows import Thickness
from System import Uri
from System.Windows.Media.Imaging import BitmapImage

# =========================================================
# DOCUMENTO
# =========================================================

uidoc = __revit__.ActiveUIDocument
doc = uidoc.Document

# =========================================================
# VENTANA PRINCIPAL
# =========================================================

class CeilingWindow(WPFWindow):

    def __init__(self):

        xamlfile = script.get_bundle_file('ui.xaml')

        WPFWindow.__init__(self, xamlfile)

        # =================================================
        # LOGO
        # =================================================

        try:

            logo_path = script.get_bundle_file('logo.png')

            bitmap = BitmapImage()

            bitmap.BeginInit()

            bitmap.UriSource = Uri(logo_path)

            bitmap.EndInit()

            self.logoImage.Source = bitmap

        except:
            pass

        # =================================================
        # DICCIONARIOS
        # =================================================

        self.level_dict = {}
        self.room_dict = {}
        self.ceiling_type_dict = {}

        # =================================================
        # CARGAR DATOS
        # =================================================

        self.load_levels()
        self.load_ceiling_types()

        self.levelCombo.SelectionChanged += self.level_changed

        self.ShowDialog()

    # =====================================================
    # NIVELES
    # =====================================================

    def load_levels(self):

        levels = FilteredElementCollector(doc) \
            .OfClass(Level) \
            .ToElements()

        ordered_levels = sorted(
            levels,
            key=lambda x: x.Elevation
        )

        for lvl in ordered_levels:

            try:

                self.level_dict[lvl.Name] = lvl

                self.levelCombo.Items.Add(
                    lvl.Name
                )

            except:
                pass

    # =====================================================
    # HABITACIONES
    # =====================================================

    def level_changed(self, sender, args):

        self.roomsPanel.Children.Clear()

        self.room_dict = {}

        selected_level_name = self.levelCombo.SelectedItem

        if not selected_level_name:
            return

        selected_level = self.level_dict[
            selected_level_name
        ]

        rooms = FilteredElementCollector(doc) \
            .OfCategory(BuiltInCategory.OST_Rooms) \
            .WhereElementIsNotElementType() \
            .ToElements()

        room_names = []

        for room in rooms:

            try:

                if room.Area <= 0:
                    continue

                if room.LevelId != selected_level.Id:
                    continue

                room_name = room.get_Parameter(
                    BuiltInParameter.ROOM_NAME
                ).AsString()

                room_number = room.get_Parameter(
                    BuiltInParameter.ROOM_NUMBER
                ).AsString()

                display = "{} - {}".format(
                    room_number,
                    room_name
                )

                self.room_dict[display] = room

                room_names.append(display)

            except:
                pass

        room_names.sort()

        for display in room_names:

            cb = CheckBox()

            cb.Content = display
            cb.Foreground = Brushes.White
            cb.Margin = Thickness(0, 5, 0, 5)
            cb.FontSize = 13
            cb.Height = 28

            self.roomsPanel.Children.Add(cb)

    # =====================================================
    # TIPOS DE TECHO
    # =====================================================

    def load_ceiling_types(self):

        ceiling_types = FilteredElementCollector(doc) \
            .OfClass(CeilingType) \
            .ToElements()

        ceiling_names = []

        for ct in ceiling_types:

            try:

                ct_name = Element.Name.GetValue(ct)

                if ct_name not in self.ceiling_type_dict:

                    self.ceiling_type_dict[ct_name] = ct

                    ceiling_names.append(ct_name)

            except:
                pass

        ceiling_names.sort()

        for name in ceiling_names:

            self.ceilingTypeCombo.Items.Add(name)

    # =====================================================
    # CONTORNOS
    # =====================================================

    def get_room_loops(self, room):

        try:

            options = SpatialElementBoundaryOptions()

            boundaries = room.GetBoundarySegments(
                options
            )

            if not boundaries:
                return None

            loops = List[CurveLoop]()

            for boundary in boundaries:

                curve_loop = CurveLoop()

                valid = False

                for segment in boundary:

                    try:

                        curve = segment.GetCurve()

                        if curve.Length <= 0:
                            continue

                        curve_loop.Append(curve)

                        valid = True

                    except:
                        pass

                if valid:
                    loops.Add(curve_loop)

            return loops

        except:
            return None

    # =====================================================
    # CREAR TECHOS
    # =====================================================

    def create_ceilings(self, sender, args):

        selected_ceiling_name = self.ceilingTypeCombo.SelectedItem

        if not selected_ceiling_name:

            forms.alert(
                "Selecciona un tipo de techo."
            )

            return

        # =================================================
        # HABITACIONES
        # =================================================

        selected_rooms = []

        for cb in self.roomsPanel.Children:

            try:

                if cb.IsChecked:

                    room = self.room_dict[
                        cb.Content
                    ]

                    selected_rooms.append(room)

            except:
                pass

        if not selected_rooms:

            forms.alert(
                "Selecciona habitaciones."
            )

            return

        # =================================================
        # ALTURA EN METROS
        # =================================================

        try:

            height_m = float(
                self.heightBox.Text
            )

            # METROS A FEET REVIT

            height_internal = (
                height_m * 3.28084
            )

        except:

            forms.alert(
                "Altura inválida."
            )

            return

        # =================================================
        # TIPO
        # =================================================

        selected_ceiling_type = self.ceiling_type_dict[
            selected_ceiling_name
        ]

        # =================================================
        # TRANSACCIÓN
        # =================================================

        t = Transaction(doc, "Techo PRO")

        t.Start()

        created = 0
        errors = []

        for room in selected_rooms:

            try:

                loops = self.get_room_loops(room)

                if not loops:
                    continue

                # =========================================
                # CREAR TECHO
                # =========================================

                ceiling = Ceiling.Create(
                    doc,
                    loops,
                    selected_ceiling_type.Id,
                    room.LevelId
                )

                doc.Regenerate()

                # =========================================
                # OFFSET ALTURA
                # =========================================

                offset = ceiling.get_Parameter(
                    BuiltInParameter
                    .CEILING_HEIGHTABOVELEVEL_PARAM
                )

                if offset and not offset.IsReadOnly:

                    offset.Set(height_internal)

                created += 1

            except Exception as e:

                try:
                    errors.append(str(e))
                except:
                    errors.append(
                        "Error desconocido"
                    )

        t.Commit()

        # =================================================
        # RESULTADOS
        # =================================================

        msg = "TECHOS CREADOS: {}\n".format(
            created
        )

        if errors:

            msg += "\nERRORES:\n\n"

            for err in errors:

                msg += err + "\n"

        forms.alert(
            msg,
            title="Proceso Finalizado"
        )

        self.Close()

# =========================================================
# EJECUTAR
# =========================================================

CeilingWindow()